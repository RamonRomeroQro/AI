import fileinput

lines = []
for line in fileinput.input():
    lines.append(line.strip())
num=list(map(int,lines))
print(sum(num))